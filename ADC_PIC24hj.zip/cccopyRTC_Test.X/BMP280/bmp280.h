/*
    @file bmp280.h

    This is a library adapted for the PIC24H to be used with the BMP280

    Based off of the Adafruit BMP280 Library

    Giovanni Wancelotti (University of Central Florida)
*/

#ifndef _BMP280_H
#define _BMP280_H

#define FOSC 20000000ULL
#define FCY (FOSC/2)

#include <stdbool.h>
#include "../mcc_generated_files/system.h"
#include <xc.h>
#include <libpic30.h>


//////////////////////////
/* Constant Definitions */
//////////////////////////

#define BMP280_ADDRESS 0x77 /* The default I2C address for the sensor */

enum{
    BMP280_REGISTER_DIG_T1 = 0x88,
    BMP280_REGISTER_DIG_T2 = 0x8A,
    BMP280_REGISTER_DIG_T3 = 0x8C,
    BMP280_REGISTER_DIG_P1 = 0x8E,
    BMP280_REGISTER_DIG_P2 = 0x90,
    BMP280_REGISTER_DIG_P3 = 0x92,
    BMP280_REGISTER_DIG_P4 = 0x94,
    BMP280_REGISTER_DIG_P5 = 0x96,
    BMP280_REGISTER_DIG_P6 = 0x98,
    BMP280_REGISTER_DIG_P7 = 0x9A,
    BMP280_REGISTER_DIG_P8 = 0x9C,
    BMP280_REGISTER_DIG_P9 = 0x9E,
    BMP280_REGISTER_CHIPID = 0xD0,
    BMP280_REGISTER_VERSION = 0xD1,
    BMP280_REGISTER_SOFTRESET = 0xE0,
    BMP280_REGISTER_CAL26 = 0xE1, /**< R calibration = 0xE1-0xF0 */
    BMP280_REGISTER_STATUS = 0xF3,
    BMP280_REGISTER_CONTROL = 0xF4,
    BMP280_REGISTER_CONFIG = 0xF5,
    BMP280_REGISTER_PRESSUREDATA = 0xF7,
    BMP280_REGISTER_TEMPDATA = 0xFA
};

typedef enum{
    /* No over-sampling. */
    SAMPLING_NONE = 0x00,
    /* 1x over-sampling. */
    SAMPLING_X1 = 0x01,
    /* 2x over-sampling. */
    SAMPLING_X2 = 0x02,
    /* 4x over-sampling. */
    SAMPLING_X4 = 0x03,
    /* 8x over-sampling. */
    SAMPLING_X8 = 0x04,
    /* 16x over-sampling. */
    SAMPLING_X16 = 0x05
}sensor_sampling ;

/** Operating mode for the sensor. */
typedef enum{
    /* Sleep mode. */
    MODE_SLEEP = 0x00,
    /* Forced mode. */
    MODE_FORCED = 0x01,
    /* Normal mode. */
    MODE_NORMAL = 0x03,
    /* Software reset. */
    MODE_SOFT_RESET_CODE = 0xB6
}sensor_mode;

/* Filtering level for sensor data. */
typedef enum{
    /* No filtering. */
    FILTER_OFF = 0x00,
    /* 2x filtering. */
    FILTER_X2 = 0x01,
    /* 4x filtering. */
    FILTER_X4 = 0x02,
    /* 8x filtering. */
    FILTER_X8 = 0x03,
    /* 16x filtering. */
    FILTER_X16 = 0x04
}sensor_filter;

/** Standby duration in ms */
typedef enum{
    /* 1 ms standby. */
    STANDBY_MS_1 = 0x00,
    /* 62.5 ms standby. */
    STANDBY_MS_63 = 0x01,
    /* 125 ms standby. */
    STANDBY_MS_125 = 0x02,
    /* 250 ms standby. */
    STANDBY_MS_250 = 0x03,
    /* 500 ms standby. */
    STANDBY_MS_500 = 0x04,
    /* 1000 ms standby. */
    STANDBY_MS_1000 = 0x05,
    /* 2000 ms standby. */
    STANDBY_MS_2000 = 0x06,
    /* 4000 ms standby. */
    STANDBY_MS_4000 = 0x07
}standby_duration;

///////////////////////////
/* Function Declarations */
///////////////////////////

/*
     @Summary
        Initializes the BMP280 Sensor on I2C

    @Description
        This routine initializes the BMP280 sensor and prepares it for use.
        User provides sampling modes based on design requirements.

    @Preconditions
        Must have initialized I2C
    
    @Param
        mode - The operating mode of the sensor.

    @Param
        temp_sampling - The sampling scheme for temp readings
            Each oversampling step reduces noise and increases the output resolution by one bit
    
    @Param
        pres_sampling - The sampling scheme for pressure readings.
            Each oversampling step reduces noise and increases the output resolution by one bit
    
    @Param
        filter - The filtering mode to apply (if any).
    
    @Param
        standby - The sampling duration.

    @Returns
        True on successful initialization and false on unsuccessful
*/

bool BMP280_Initialize  (sensor_mode mode, 
                        sensor_sampling temp_sampling, 
                        sensor_sampling pres_sampling, 
                        sensor_filter filter, 
                        standby_duration standby);

/*
     @Summary
        Reads temperature from the BMP280

    @Description
        This routine uses the I2C bus to read the temperature registers and
        converts it to degrees Celsius

    @Preconditions
        Must have called BMP280_Initialize
    
    @Param
        None

    @Returns
        Temperature in degrees Celsius
*/

float BMP280_ReadTemperature(void);

/*
     @Summary
        Reads pressure from the BMP280

    @Description
        This routine uses the I2C bus to read the pressure registers and
        converts it to Barometric pressure in Pa

    @Preconditions
        Must have called BMP280_Initialize
    
    @Param
        None

    @Returns
        Barometric pressure in Pa
*/

float BMP280_ReadPressure(void);

#endif