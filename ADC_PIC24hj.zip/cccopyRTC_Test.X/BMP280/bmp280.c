#include "bmp280.h"
#include <stdint.h>
#include <stdio.h>
#include "../mcc_generated_files/i2c1.h"

//for debuggin
#include "../OLED/OLED.h"

#define SLAVE_I2C_GENERIC_DEVICE_TIMEOUT 100
#define SLAVE_I2C_GENERIC_RETRY_MAX 200

typedef struct{
    sensor_mode mode;
    sensor_sampling osrs_t;
    sensor_sampling osrs_p;
    sensor_filter filter;
    standby_duration standby;

    uint16_t dig_T1; /**< dig_T1 cal register. */
    int16_t dig_T2;  /**<  dig_T2 cal register. */
    int16_t dig_T3;  /**< dig_T3 cal register. */
    int32_t t_fine;

    uint16_t dig_P1; /**< dig_P1 cal register. */
    int16_t dig_P2;  /**< dig_P2 cal register. */
    int16_t dig_P3;  /**< dig_P3 cal register. */
    int16_t dig_P4;  /**< dig_P4 cal register. */
    int16_t dig_P5;  /**< dig_P5 cal register. */
    int16_t dig_P6;  /**< dig_P6 cal register. */
    int16_t dig_P7;  /**< dig_P7 cal register. */
    int16_t dig_P8;  /**< dig_P8 cal register. */
    int16_t dig_P9;  /**< dig_P9 cal register. */
}BMP280_Sensor;

BMP280_Sensor BMP280;

/*Local Functions*/
bool BMP280_SendCommand(uint8_t reg, uint8_t command);
bool BMP280_Read(uint8_t reg, uint8_t *data, uint8_t nBytes);

//wrappers for the BMP280_Read
uint16_t BMP280_Read16(uint8_t reg);
uint32_t BMP280_Read24(uint8_t reg);
int16_t UnsignToSign16(uint16_t unsign);

void readCoefficients(void);

/*Globals*/

bool BMP280_Initialize  (sensor_mode mode,
                        sensor_sampling temp_sampling,
                        sensor_sampling pres_sampling,
                        sensor_filter filter,
                        standby_duration standby)
{
    BMP280.mode = mode;
    BMP280.osrs_t = temp_sampling;
    BMP280.osrs_p = pres_sampling;
    BMP280.filter = filter;
    BMP280.standby = standby;

    uint8_t control = (BMP280.osrs_t << 5) | (BMP280.osrs_p << 2) | BMP280.mode;
    uint8_t config = (BMP280.standby << 5) | (BMP280.filter << 2) | 0; /*SPI enable off */
    
    readCoefficients();

    if(BMP280_SendCommand(BMP280_REGISTER_CONTROL, control) == false)
        return false;
    if(BMP280_SendCommand(BMP280_REGISTER_CONFIG, config) == false)
        return false;
    

    return true;
}

float BMP280_ReadTemperature(void)
{
  int32_t var1, var2;
  
  int32_t adc_T = BMP280_Read24(BMP280_REGISTER_TEMPDATA);
  adc_T >>= 4;
  

  var1 = ((((adc_T >> 3) - ((int32_t)BMP280.dig_T1 << 1))) *
          ((int32_t)BMP280.dig_T2)) >>
         11;

  var2 = (((((adc_T >> 4) - ((int32_t)BMP280.dig_T1)) *
            ((adc_T >> 4) - ((int32_t)BMP280.dig_T1))) >>
           12) *
          ((int32_t)BMP280.dig_T3)) >>
         14;

  BMP280.t_fine = var1 + var2; //also needed for pressure

  float T = (BMP280.t_fine * 5 + 128) >> 8;
  return  T / 100;
}

float BMP280_ReadPressure(void)
{
    int64_t var1, var2, p;

      // Must be done first to get the t_fine variable set up
      //readTemperature();

    int32_t adc_P = BMP280_Read24(BMP280_REGISTER_PRESSUREDATA);
    adc_P >>= 4;

    var1 = ((int64_t)BMP280.t_fine) - 128000;
    var2 = var1 * var1 * (int64_t)BMP280.dig_P6;
    var2 = var2 + ((var1 * (int64_t)BMP280.dig_P5) << 17);
    var2 = var2 + (((int64_t)BMP280.dig_P4) << 35);
    var1 = ((var1 * var1 * (int64_t)BMP280.dig_P3) >> 8) +
             ((var1 * (int64_t)BMP280.dig_P2) << 12);
    var1 =
        (((((int64_t)1) << 47) + var1)) * ((int64_t)BMP280.dig_P1) >> 33;

    if (var1 == 0) {
        return 0; // avoid exception caused by division by zero
    }
    
    p = 1048576 - adc_P;
    p = (((p << 31) - var2) * 3125) / var1;
    var1 = (((int64_t)BMP280.dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2 = (((int64_t)BMP280.dig_P8) * p) >> 19;
    p = ((p + var1 + var2) >> 8) + (((int64_t)BMP280.dig_P7) << 4);
    return (float)p / 256;
}

/* Supporting Functions */

bool BMP280_SendCommand(uint8_t reg, uint8_t command)
{
    uint8_t data[2] = {reg, command};
    I2C1_MESSAGE_STATUS status = I2C1_MESSAGE_PENDING;
    uint8_t timeOut = 0;
    uint8_t slaveTimeOut = 0;

    while(status != I2C1_MESSAGE_FAIL)
    {
        I2C1_MasterWrite(data, 2, BMP280_ADDRESS, &status);

        while(status == I2C1_MESSAGE_PENDING)
        {
            //__delay_ms(1);
            //__delay_us(10);
            uint8_t i;
            for(i = 0; i < 50; i++);
            // timeout checking
            // check for max retry and skip this byte
            if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
                break;
            else
                slaveTimeOut++;
        }
        if ((slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT) ||
                (status == I2C1_MESSAGE_COMPLETE))
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (timeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
                break;
            else
                timeOut++;
    }

    if(status == I2C1_MESSAGE_COMPLETE)
        return true;
    else
        return false;

}

bool BMP280_Read(uint8_t reg, uint8_t *data, uint8_t nBytes)
{
    I2C1_MESSAGE_STATUS status = I2C1_MESSAGE_PENDING;
    uint16_t    retryTimeOut, slaveTimeOut;


    // Now it is possible that the slave device will be slow.
    // As a work around on these slaves, the application can
    // retry sending the transaction
    retryTimeOut = 0;
    slaveTimeOut = 0;

    while(status != I2C1_MESSAGE_FAIL)
    {
        // write one byte
        I2C1_MasterWrite(&reg, 1, BMP280_ADDRESS, &status);

        // wait for the message to be sent or status has changed.
        while(status == I2C1_MESSAGE_PENDING)
        {
            // add some delay here
            //__delay_ms(1);
            //__delay_us(100);
            uint8_t i;
            for(i = 0; i < 50; i++);
            // timeout checking
            // check for max retry and skip this byte
            if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
            {
                return (false);
            }
            else
                slaveTimeOut++;
        }

        if (status == I2C1_MESSAGE_COMPLETE)
            break;

        // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
        //               or I2C1_DATA_NO_ACK,
        // The device may be busy and needs more time for the last
        // write so we can retry writing the data, this is why we
        // use a while loop here

        // check for max retry and skip this byte
        if (retryTimeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
            break;
        else
            retryTimeOut++;
    }

    if (status == I2C1_MESSAGE_COMPLETE)
    {

        // this portion will read the byte from the memory location.
        retryTimeOut = 0;
        slaveTimeOut = 0;

        while(status != I2C1_MESSAGE_FAIL)
        {
            //read
            I2C1_MasterRead(data, nBytes, BMP280_ADDRESS, &status);

            // wait for the message to be sent or status has changed.
            while(status == I2C1_MESSAGE_PENDING)
            {
                // add some delay here
                
                uint8_t i;
                for(i = 0; i < 50; i++);
                //__delay_ms(1);
                //__delay_us(10);
                // timeout checking
                // check for max retry and skip this byte
                if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
                {
                    return false;
                }
                else
                    slaveTimeOut++;
            }

            if (status == I2C1_MESSAGE_COMPLETE)
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (retryTimeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
                break;
            else
                retryTimeOut++;
        }
    }

    // exit if the last transaction failed
    if (status == I2C1_MESSAGE_FAIL)
    {
//        OLED_Write_Text(0,24, "Read Fail!");
//        OLED_Update();
//        __delay_ms(200);
//        OLED_ClearDisplay();
//        OLED_Update();
//        __delay_ms(200);
        return(false);
    }                                                                                             

    return(true);
}

//wrapper for the read function
uint16_t BMP280_Read16(uint8_t reg)
{
    uint8_t data[2];
    uint16_t value;
    bool result = BMP280_Read(reg, data, 2);
    if(result == true)
        value = (uint16_t)(data[0] << 8) | (uint16_t)data[1];
    else
        value = 0;
    return value;
}

uint16_t BMP280_Read16LE(uint8_t reg)
{
    uint8_t data[2];
    BMP280_Read(reg, data, 2);
    uint16_t value = ((uint16_t)data[1] << 8) | (uint16_t)data[0];
    return value;
}

uint32_t BMP280_Read24(uint8_t reg)
{
    uint8_t data[3];
    bool result = BMP280_Read(reg, data, 3);
    if(result == true)
    {
        uint32_t value = 0 | ((uint32_t)data[0] << 16) | (uint16_t)(data[1] << 8) | data[2];
        return value;
    }
    else
    {
//        LATBbits.LATB7 = 1;
//        __delay_ms(1);
//        LATBbits.LATB7 = 0;
        return 0;
    }
}

int16_t UnsignToSign16(uint16_t unsign)
{
  int16_t sign;
  sign = 0 | unsign;
  return sign;
}

void readCoefficients(void){
  LATBbits.LATB7 = 1;
  BMP280.dig_T1 = BMP280_Read16(BMP280_REGISTER_DIG_T1);
  LATBbits.LATB7 = 0;
  
  BMP280.dig_T2 = 0 | BMP280_Read16(BMP280_REGISTER_DIG_T2);
  BMP280.dig_T3 = 0 | BMP280_Read16(BMP280_REGISTER_DIG_T3);
  
  
  BMP280.dig_P1 = BMP280_Read16(BMP280_REGISTER_DIG_P1);
  BMP280.dig_P2 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P2));
  BMP280.dig_P3 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P3));
  BMP280.dig_P4 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P4));
  BMP280.dig_P5 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P5));
  BMP280.dig_P6 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P6));
  BMP280.dig_P7 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P7));
  BMP280.dig_P8 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P8));
  BMP280.dig_P9 = UnsignToSign16(BMP280_Read16(BMP280_REGISTER_DIG_P9));
  
  /*debug
  __delay_ms(500);
  OLED_ClearDisplay();
  char str[16];
  sprintf(str, "T1: %d", BMP280.dig_T1);
  OLED_Write_Text(0,0,str);
  
  sprintf(str, "T2: %d", BMP280.dig_T2);
  OLED_Write_Text(0,8,str);
  sprintf(str, "T3: %d", BMP280.dig_T3);
  OLED_Write_Text(0,16,str);
  OLED_Update();
  __delay_ms(2000);
  */
}
