                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    /**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.170.0
        Device            :  PIC24FJ128GA006
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.61
        MPLAB 	          :  MPLAB X v5.45
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/

#define FOSC 20000000ULL
#define FCY (FOSC/2)

#include "mcc_generated_files/system.h"
#include <xc.h>
#include <libpic30.h>

#include <stdio.h>
#include <math.h>

#include "OLED/OLED.h"
#include "BMP280/bmp280.h"
#include "ADXL343/ADXL343.h"
#include "DS3231/DS3231.h"

//BOREN = OFF 
 
int ADCValue = 0;
int ADCValue2 = 0;
float avalue = 0.0; //analog value for adc
float avalue2 = 0.0; //analog value for adc

void configADC(void);
 //void__attribute__((interupt, auto_psc)) _ADC1Interrupt (void) ;

/*
                         Main application
 */
int main(void)
    
{
    
    
    // initialize the device
    SYSTEM_Initialize();
     _TRISA1 = 1; //sets pin to input AN1
        _PCFG1 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
           _TRISA0 = 1; //sets pin to input AN0
        _PCFG0 = 0; //0 = Port pin in Analog mode, port read input disabled, ADC samples pin voltage
    OLED_Init();
    __delay_ms(1000);
    
    char str[32]; // for olded

       
        
        
        

    
    configADC(); //settings for adc
   

   int x=0; 
   for (x; x< 2; x++) // repeat continuously for adc
   {
        OLED_ClearDisplay();
        sprintf(str, "AN0", str);
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(100);
        
        _CH0SA = 0; //NEED FOR THE ADC CHANNEL 
        
        _ADON = 1; // turn ADC ON
 
   __delay_ms(100); // sample for 100 mS
   
    AD1CON1bits.SAMP = 0; // start Converting
    
  // while (!AD1CON1bits.DONE);// conversion done?
    if (AD1CON1bits.DONE = 1)
    {
    ADCValue = ADC1BUF0; // yes then get ADC value
    AD1CON1bits.DONE = 0; //CLEAR FLAG
    }

    avalue= (ADCValue * 3.3) / 1024; //will give actual volatage value
        
       //display adc value
        OLED_ClearDisplay();
        sprintf(str, "Analog is %f", (double)avalue );
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(1000);
//_ADON = 0;
      } // repeat
  // _ADON = 0; //ADC off
   
   int Z=0; 
   for (Z; Z<2; Z++) // repeat continuously for adc
   {
        OLED_ClearDisplay();
        sprintf(str, "AN1", str);
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(100);
        
     _ADON = 0; 
      _CH0SA = 1; //NEED TO CHANGE FROM AN0 TO AN1
     
        _ADON = 1; // turn ADC ON
 
   __delay_ms(100); // sample for 100 mS
   
    AD1CON1bits.SAMP = 0; // start Converting
    
  // while (!AD1CON1bits.DONE);// conversion done?
    if (AD1CON1bits.DONE = 1)
    {
        
    ADCValue2 = ADCBUF0; // yes then get ADC value
    AD1CON1bits.DONE = 0; //CLEAR FLAG 
    }

    avalue2= (ADCValue2 * 3.3) / 1024; //will give actual volatage value
        
       //display adc value
        OLED_ClearDisplay();
        sprintf(str, "Analog is %f", (double)avalue2 );
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(1000);
//_ADON = 0;
      } // repeat
    OLED_ClearDisplay();
        sprintf(str, "end", str);
        OLED_Write_Text(0,0,str);
        OLED_Update();
        __delay_ms(100);
    return;
}




void configADC(void){
    //register ad1con1
    _ADON = 0; //ADC IS OFF, LEAVE THIS NOT TO MESS UP SETTING UP
    //ADSIDL FOR IDLE MODE
    _AD12B = 0 ; // SETS 12 BIT, 1 CH, 0 IS 10 BIT 4CH CHANGE SIMSAM TOO
    _FORM = 0; //POSITIVE INTEGER
    _SSRC = 7; //BINARY 111
    _ASAM = 1; // AUTOSETS SAMPLINGS
    _SIMSAM = 1; // SAMPLES CHS SIMULATANEOUSLY
            
    //REGISTER AD1CON2
    _VCFG = 000; //SETS VOLT REF
    //_CSCNA SCANS CHANNELS
    _CHPS = 01; //SETS CH0 AND CH1
    //BUFS MAKE BUFFER FASTER
    _SMPI = 0;
    //_BUFM START FILLING BUFFER
    
    //REGISTER AD1CON3
    _ADRC = 1; //INTERNAL RC CLOCK
    
    //ACTIVATE AD1CHS123 WHEN USING MORE THAN 1 CH
    //register AD1CHS123
    _CH123SB = 0; //SETS AN0, AN1, AND AN2 AS POS CH
    
    
    //REGISTER AD1CHS
    _CH0NA = 0;//NEG REF IS VREF-
    //_CH0SA = 00000; // POS IS AN0
    //_CH0SA1 = 00001;
  
    
   
            
    //REGISTER INTCON1
    _NSTDIS = 0 ; //DISABLE INTERRUPT OVERLAP
    
    //REGISTER INTERUPT FLAG 
    _AD1IF = 0;//CONVERSION STATUS FOR ADC, 0 CLEARS THE FLAG
   _AD1IE = 1; //CONVERSION
   //IPC
   _AD1IP = 0 ;//PRIORITY FOR ADC INTERRUPTS, 7 HIGH, 0 OFF
   
  //   _ADON = 1 ;//TURNS ADC ON
}       
  /* void__attribute__((interupt, auto_psc)) _ADC1Interrupt (void)
   {
       _AD1IF = 0;
       ADCValue = ADC1BUF0 ; //BUFFER WHERE VALUES IS STORED
   }
    
    
     
}*/



