#include "ADXL343.h"
#include "../mcc_generated_files/i2c1.h"
#include <stdint.h>

#define SLAVE_I2C_GENERIC_DEVICE_TIMEOUT 100
#define SLAVE_I2C_GENERIC_RETRY_MAX 200

#define ADXL343_MG2G_MULTIPLIER (0.004) // 4mg per lsb
#define GRAVITY_EARTH (9.80665F) // Earth's gravity in m/s^2

//Supporting Functions
bool ADXL343_SendCommand(uint8_t reg, uint8_t command);
bool ADXL343_Read(uint8_t reg, uint8_t *data, uint8_t nBytes);

uint16_t ADXL343_Read16(uint8_t reg);

bool ADXL343_Initialize(dataRate_t rate, range_t range)
{
    uint8_t data_format = 0b00001000;
    //self test(7), SPI (6), INT_INVERT(5), unused(4), FULL_RES(3)
    //justify(2), range(1-0)
    data_format |= range;

    uint8_t bw_rate = 0 | rate;
    
    uint8_t fifo_ctl = 0;

    if(ADXL343_SendCommand(ADXL343_REG_INT_ENABLE, 0) == false)  // Disable interrupts to start
        return false;
    if(ADXL343_SendCommand(ADXL343_REG_POWER_CTL, 0x08) == false)
        return false;
    if(ADXL343_SendCommand(ADXL343_REG_DATA_FORMAT, data_format) == false)
        return false;
    if(ADXL343_SendCommand(ADXL343_REG_BW_RATE, bw_rate) == false)
        return false;
    if(ADXL343_SendCommand(ADXL343_REG_FIFO_CTL, fifo_ctl) == false)
        return false;
    
    return true;
}

float ADXL343_getX_Accel(void)
{
    float acceleration = ADXL343_getX() * ADXL343_MG2G_MULTIPLIER * GRAVITY_EARTH;
    return acceleration;
}

float ADXL343_getY_Accel(void)
{
    float acceleration = ADXL343_getY() * ADXL343_MG2G_MULTIPLIER * GRAVITY_EARTH;
    return acceleration;
}

float ADXL343_getZ_Accel(void)
{
    float acceleration = ADXL343_getZ() * ADXL343_MG2G_MULTIPLIER * GRAVITY_EARTH;
    return acceleration;
}


int16_t ADXL343_getX(void)
{
    //read 32 (full FIFO) and average
    /*
    uint8_t i;
    int32_t sum = 0;
    for(i = 0; i < 32; i++)
    {
        int16_t data = 0 | ADXL343_Read16(ADXL343_REG_DATAX0);
        sum += data;
    }
    return sum/32; //cuts off decimal
    */
    int16_t data = 0 | ADXL343_Read16(ADXL343_REG_DATAX0);
    return data;
}

int16_t ADXL343_getY(void)
{
    //read 32 (full FIFO) and average
    /*
    uint8_t i;
    int32_t sum = 0;
    for(i = 0; i < 32; i++)
    {
        int16_t data = 0 | ADXL343_Read16(ADXL343_REG_DATAY0);
        sum += data;
    }
    return sum/32; //cuts off decimal
    */
    int16_t data = 0 | ADXL343_Read16(ADXL343_REG_DATAY0);
    return data;
}

int16_t ADXL343_getZ(void)
{
    //read 32 (full FIFO) and average
    /*
    uint8_t i;
    int32_t sum = 0;
    for(i = 0; i < 32; i++)
    {
        int16_t data = 0 | ADXL343_Read16(ADXL343_REG_DATAZ0);
        sum += data;
    }
    return sum/32; //cuts off decimal
    */
    int16_t data = 0 | ADXL343_Read16(ADXL343_REG_DATAZ0);
    return data;
}

//Supporting function definitions

uint16_t ADXL343_Read16(uint8_t reg)
{
    uint8_t data[2];
    uint16_t value;
    bool result = ADXL343_Read(reg, data, 2);
    if(result == true)
        value = (uint16_t)(data[1] << 8) | (uint16_t)data[0];
    else
        value = 0;
    return value;
}

bool ADXL343_SendCommand(uint8_t reg, uint8_t command)
{
    uint8_t data[2] = {reg, command};
    I2C1_MESSAGE_STATUS status = I2C1_MESSAGE_PENDING;
    uint8_t timeOut = 0;
    uint8_t slaveTimeOut = 0;

    while(status != I2C1_MESSAGE_FAIL)
    {
        I2C1_MasterWrite(data, 2, ADXL343_ADDRESS, &status);

        while(status == I2C1_MESSAGE_PENDING)
        {
            //__delay_ms(1);
            //__delay_us(10);
            uint8_t i;
            for(i = 0; i < 50; i++);
            // timeout checking
            // check for max retry and skip this byte
            if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
                break;
            else
                slaveTimeOut++;
        }
        if ((slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT) ||
                (status == I2C1_MESSAGE_COMPLETE))
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (timeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
                break;
            else
                timeOut++;
    }

    if(status == I2C1_MESSAGE_COMPLETE)
        return true;
    else
        return false;

}

bool ADXL343_Read(uint8_t reg, uint8_t *data, uint8_t nBytes)
{
    I2C1_MESSAGE_STATUS status = I2C1_MESSAGE_PENDING;
    uint16_t    retryTimeOut, slaveTimeOut;


    // Now it is possible that the slave device will be slow.
    // As a work around on these slaves, the application can
    // retry sending the transaction
    retryTimeOut = 0;
    slaveTimeOut = 0;

    while(status != I2C1_MESSAGE_FAIL)
    {
        // write one byte
        I2C1_MasterWrite(&reg, 1, ADXL343_ADDRESS, &status);

        // wait for the message to be sent or status has changed.
        while(status == I2C1_MESSAGE_PENDING)
        {
            // add some delay here
            //__delay_ms(1);
            //__delay_us(100);
            uint8_t i;
            for(i = 0; i < 50; i++);
            // timeout checking
            // check for max retry and skip this byte
            if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
            {
                return (false);
            }
            else
                slaveTimeOut++;
        }

        if (status == I2C1_MESSAGE_COMPLETE)
            break;

        // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
        //               or I2C1_DATA_NO_ACK,
        // The device may be busy and needs more time for the last
        // write so we can retry writing the data, this is why we
        // use a while loop here

        // check for max retry and skip this byte
        if (retryTimeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
            break;
        else
            retryTimeOut++;
    }

    if (status == I2C1_MESSAGE_COMPLETE)
    {

        // this portion will read the byte from the memory location.
        retryTimeOut = 0;
        slaveTimeOut = 0;

        while(status != I2C1_MESSAGE_FAIL)
        {
            //read
            I2C1_MasterRead(data, nBytes, ADXL343_ADDRESS, &status);

            // wait for the message to be sent or status has changed.
            while(status == I2C1_MESSAGE_PENDING)
            {
                // add some delay here
                
                uint8_t i;
                for(i = 0; i < 50; i++);
                //__delay_ms(1);
                //__delay_us(10);
                // timeout checking
                // check for max retry and skip this byte
                if (slaveTimeOut == SLAVE_I2C_GENERIC_DEVICE_TIMEOUT)
                {
                    return false;
                }
                else
                    slaveTimeOut++;
            }

            if (status == I2C1_MESSAGE_COMPLETE)
                break;

            // if status is  I2C1_MESSAGE_ADDRESS_NO_ACK,
            //               or I2C1_DATA_NO_ACK,
            // The device may be busy and needs more time for the last
            // write so we can retry writing the data, this is why we
            // use a while loop here

            // check for max retry and skip this byte
            if (retryTimeOut == SLAVE_I2C_GENERIC_RETRY_MAX)
                break;
            else
                retryTimeOut++;
        }
    }

    // exit if the last transaction failed
    if (status == I2C1_MESSAGE_FAIL)
    {
//        OLED_Write_Text(0,24, "Read Fail!");
//        OLED_Update();
//        __delay_ms(200);
//        OLED_ClearDisplay();
//        OLED_Update();
//        __delay_ms(200);
        return(false);
    }                                                                                             

    return(true);
}